//
//  ASettingsTableViewController.h
//  Alpha
//
//  Created by Kevin Lin on 10/14/14.
//  Copyright (c) 2014 cs378. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASettingsTableViewController : UITableViewController

@end
